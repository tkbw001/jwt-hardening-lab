// secure-server1.js (النسخة النهائية - مدمج بها Helmet و HTTPS)
require('dotenv').config();

// --- 1. استدعاء كل المكتبات مرة واحدة فوق ---
const https = require('https');
const fs = require('fs');
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cookieParser = require('cookie-parser');
const helmet = require('helmet'); // مكتبة الخوذة

// --- 2. إعدادات السيرفر الأساسية ---
const app = express();
const PORT = 1235; // البورت الآمن

// --- 3. تشغيل الـ Middleware بالترتيب الصح ---
app.use(helmet()); // شغل الخوذة الأول عشان تأمن كل الطلبات
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// --- 4. قراءة الإعدادات والمتغيرات من .env ---
const DB = new sqlite3.Database(process.env.DATABASE_URL);
const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET;
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET;

// مخزن مؤقت للـ Refresh Tokens
const refreshStore = new Map();

// --- 5. الـ Endpoints بتاعة السيرفر (Login, Refresh, Admin) ---
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  DB.get("SELECT * FROM users WHERE username = ?", [username], (err, row) => {
    if (err || !row || !bcrypt.compareSync(password, row.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const accessToken = jwt.sign({ sub: row.username, role: row.role }, ACCESS_TOKEN_SECRET, { expiresIn: '15m', issuer: process.env.ISSUER, audience: process.env.AUDIENCE });
    const tokenId = Math.random().toString(36).slice(2);
    const refreshToken = jwt.sign({ sub: row.username, tid: tokenId }, REFRESH_TOKEN_SECRET, { expiresIn: '7d', issuer: process.env.ISSUER, audience: process.env.AUDIENCE });
    refreshStore.set(tokenId, { username: row.username });
    res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: true, sameSite: 'Strict', maxAge: 7 * 24 * 60 * 60 * 1000 });
    return res.json({ accessToken });
  });
});

app.post('/refresh', (req, res) => {
  const token = req.cookies.refreshToken;
  if (!token) return res.status(401).json({ error: 'No refresh token' });
  try {
    const payload = jwt.verify(token, REFRESH_TOKEN_SECRET, { algorithms: ['HS256'], issuer: process.env.ISSUER, audience: process.env.AUDIENCE });
    const storedToken = refreshStore.get(payload.tid);
    if (!storedToken || storedToken.username !== payload.sub) {
      return res.status(401).json({ error: 'Invalid refresh token' });
    }
    const accessToken = jwt.sign({ sub: payload.sub, role: 'user' }, ACCESS_TOKEN_SECRET, { expiresIn: '15m', issuer: process.env.ISSUER, audience: process.env.AUDIENCE });
    return res.json({ accessToken });
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired refresh token' });
  }
});

app.get('/admin', (req, res) => {
  const auth = (req.headers.authorization || '');
  const token = auth.replace('Bearer ', '').trim();
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const payload = jwt.verify(token, ACCESS_TOKEN_SECRET, { algorithms: ['HS256'], issuer: process.env.ISSUER, audience: process.env.AUDIENCE });
    if (payload.role === 'admin') {
      return res.json({ secret: 'VERY SENSITIVE ADMIN DATA (SECURE)' });
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
});

// --- 6. إعدادات شهادة الـ HTTPS ---
const httpsOptions = {
  key: fs.readFileSync('key.pem'),
  cert: fs.readFileSync('cert.pem')
};

// --- 7. تشغيل السيرفر الآمن باستخدام HTTPS ---
https.createServer(httpsOptions, app).listen(PORT, () => {
  console.log(`>>> SECURE HTTPS SERVER (with Helmet) <<< running at https://localhost:${PORT}`);
});
