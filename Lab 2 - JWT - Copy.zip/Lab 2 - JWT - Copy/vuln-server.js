// vuln-server.js  (النسخة الضعيفة الأصلية للهجوم)
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// الإعدادات الضعيفة الأصلية
const PORT = 1234;
const DB = new sqlite3.Database('./users.db');
const WEAK_SECRET = 'weak-secret'; // <--- السر الضعيف جدًا

// Login ضعيف: بيصدر توكن عمره 7 أيام بالسر الضعيف
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  DB.get("SELECT * FROM users WHERE username = ?", [username], (err, row) => {
    if (!row || !bcrypt.compareSync(password, row.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ sub: row.username, role: row.role }, WEAK_SECRET, { algorithm: 'HS256', expiresIn: '7d' });
    return res.json({ token });
  });
});

/*
  الـ Admin Endpoint اللي فيه ثغرة alg:none
*/
app.get('/admin', (req, res) => {
  const auth = (req.headers.authorization || '');
  const token = auth.replace('Bearer ', '').trim();
  if (!token) return res.status(401).json({ error: 'No token' });

  let header;
  try {
    header = JSON.parse(Buffer.from(token.split('.')[0], 'base64').toString('utf8'));
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token header' });
  }

  // الثغرة الخطيرة هنا
  if (header && String(header.alg).toLowerCase() === 'none') {
    const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString('utf8'));
    if (payload && payload.role === 'admin') {
      return res.json({ secret: 'ACCESSED VIA alg:none DEMO' });
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }
  }

  // التحقق العادي بالسر الضعيف
  try {
    const decoded = jwt.verify(token, WEAK_SECRET);
    if (decoded.role === 'admin') return res.json({ secret: 'SENSITIVE ADMIN DATA' });
    return res.status(403).json({ error: 'Forbidden' });
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
});

app.listen(PORT, () => console.log(`<<< VULNERABLE SERVER >>> running at http://localhost:${PORT}`));