﻿
**Demonstrate attacks & protections (required):**

![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.001.png)

![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.002.bmp)












![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.003.bmp)






![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.004.png)


![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.005.png)

HTTP:

![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.006.png)

HTTPS:\
![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.007.png)

![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.008.png)

![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.009.png) 

Helmet:

![](Aspose.Words.1df13f80-ddcf-448d-a467-2f6dc218a718.010.png)





\# Assignment 2 - JWT Hardening

This project involves hardening a vulnerable Node.js JWT authentication lab. The goal was to implement secure authentication practices, demonstrate attacks against the original vulnerable server, and prove that these attacks fail against the new, hardened server.

\---

\## 🚀 How to Run the Project

\### 1. Initial Setup

\- Clone the repository to your local machine.

\- Install the required dependencies:

`  ````bash

`  `npm install

- Initialize the SQLite database with sample users (alice/alicepass, admin/adminpass):

  Bash

  npm run init-db

**2. Environment Configuration**

- Create a .env file in the root of the project by copying the example file:

  Bash

  cp .env.example .env

- Populate the .env file with the required values. **Secrets must be strong and randomly generated.**

**How to Generate Secure Secrets**

Use the following Node.js command in your terminal to generate a secure, random 64-byte hex string for ACCESS\_TOKEN\_SECRET and REFRESH\_TOKEN\_SECRET:

Bash

node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

**3. Running the Servers**

You can run the vulnerable server or the secure server using the following commands:

- **To run the VULNERABLE server (on HTTP port 1234):**

  Bash

  npm run start-vuln

- **To run the SECURE server (on HTTPS port 1235):**

  Bash

  npm run start-secure

-----
**Attacks & Protections Demonstrated**

At least two attack scenarios were demonstrated as required.

**Attack 1: alg:none Header Trick**

This attack exploits a vulnerability where the server trusts the token's header algorithm. By changing the alg to none and modifying the payload to grant admin privileges, we can bypass signature verification on the vulnerable server.

**Vulnerable Server (Attack SUCCESS):**

- An alg:none token with role: "admin" was sent to GET /admin.
- The server was successfully compromised, returning a 200 OK status with sensitive admin data.

**Hardened Server (Attack FAILED):**

- The *exact same* malicious token was sent to the secure server at GET /admin.
- The attack failed. The server correctly identified the token as invalid and returned a 401 Unauthorized error.
- This was fixed by explicitly requiring the HS256 algorithm during token verification (jwt.verify).
-----
**Wireshark Traffic Analysis**

Wireshark was used to demonstrate the critical importance of using HTTPS over HTTP.

- **Capture Interface:** Adapter for loopback traffic capture was used to monitor local traffic.
- **Filter Used:** tcp.port == 1234 for the vulnerable server and tcp.port == 1235 for the secure server.

**On HTTP (Vulnerable):**

- The JWT Access Token was clearly visible in plain text in the response body after a successful login. This means anyone on the network could steal the token.

**On HTTPS (Secure):**

- All traffic, including the token, was fully encrypted using TLSv1.3. The payload is shown as "Encrypted Application Data," proving that the token is protected from eavesdropping.
-----
**✨ Bonus Work Completed**

**A. HTTPS Locally**

- A self-signed certificate (cert.pem) and private key (key.pem) were generated using **OpenSSL**.
- The secure server was configured to use Node's built-in https module to serve traffic exclusively over HTTPS on port 1235.
- The browser shows a "Not Secure" warning, which is expected for a self-signed certificate, confirming HTTPS is active.

**B. Helmet & Secure Headers**

- The **Helmet.js** library was added to the secure server.
- By simply adding app.use(helmet());, a suite of security-focused HTTP headers were automatically applied to all responses, protecting against common attacks like XSS, clickjacking, and others.

